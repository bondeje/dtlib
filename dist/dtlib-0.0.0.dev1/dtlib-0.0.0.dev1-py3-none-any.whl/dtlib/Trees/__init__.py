from . import _ArrayBinaryTree
from . import _LinkedBinaryTree
from . import BinaryTree
#from . import ArrayBinarySearchTree
#from . import LinkedBinarySearchTree
from . import BinarySearchTree
from . import _constants
from . import _config # TODO: remove dependencys in LinkedBinaryTree and remove

#from BLib.Trees._config import *