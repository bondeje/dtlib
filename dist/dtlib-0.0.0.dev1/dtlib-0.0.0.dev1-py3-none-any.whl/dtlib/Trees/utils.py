# -*- coding: utf-8 -*-
"""
Created on Mon Sep  5 09:17:08 2022

@author: jeffr
"""

import math

def binary_tree_level(index):
    return int(math.log2(index+1))